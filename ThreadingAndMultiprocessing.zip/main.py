
#Threading and Multiproessing:
# https://docs.python.org/3/library/multiprocessing.html
# https://docs.python.org/3/library/threading.html

#Threading korle program execution time onk kome jai.

#general Coding:This is executing sequentially(1 by 1)
from time import (  #Time module theke time and sleep function ta import korlam.
  sleep,
  time,
)

start_time=time() #Time function start korlam and value ta start_time a assign korlam.
def something(): #Something name function create korlam,jar kaj hobe every object k 2 seconds sleep kora.
  print("Sleep for 2 seconds")
  sleep(2)
  print("Wake up")

for _ in range(4): #4 ta object create kora holo.Total 8 seconds sleep hobe
  something()

end_time=time() #Time function end korlam and value ta end_time a assign korlam.

print(f"Main thread ended in {end_time-start_time} seconds")


#Same code using Threading:Time will be constant
#Below code takes 2 seconds to execute.
from time import sleep, time
import threading

start_time=time()

def something(id): 

  print(f"Sleep for 2 seconds,ID: {id}")
  sleep(2)
  print(f"Wake up,ID: {id}")

t1=threading.Thread(target=something,args=[1])
t2=threading.Thread(target=something,args=[2])
t3=threading.Thread(target=something,args=[3])
t4=threading.Thread(target=something,args=[4])

t1.start()
t2.start()
t3.start()
t4.start()

t1.join()
t2.join()
t3.join()
t4.join()

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")

print(" ")
print("Same code but differnt Number of object")
print(" ")

#Below code takes 2 seconds to execute.

from time import sleep, time
import threading

start_time=time()

def something(id):

  print(f"Sleep for 2 seconds,ID: {id}")
  sleep(2)
  print(f"Wake up,ID: {id}")

t1=threading.Thread(target=something,args=[1])
t2=threading.Thread(target=something,args=[2])
t3=threading.Thread(target=something,args=[3])
t4=threading.Thread(target=something,args=[4])
t5=threading.Thread(target=something,args=[5])
t6=threading.Thread(target=something,args=[6])
t7=threading.Thread(target=something,args=[7])
t8=threading.Thread(target=something,args=[8])

t1.start()
t2.start()
t3.start()
t4.start()
t5.start()
t6.start()
t7.start()
t8.start()

t1.join()
t2.join()
t3.join()
t4.join()
t5.join()
t6.join()
t7.join()
t8.join()

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")


#Jodi loop use kori tobe:Below code also takes 2 seconds to execute.
import threading
from time import sleep, time

start_time=time()

def something(id): 

  print(f"Sleep for 2 seconds,ID: {id}")
  sleep(2)
  print(f"Wake up,ID: {id}")

threads=[threading.Thread(target=something,args=[i]) for i in range(10)]

for thread in threads:
  thread.start()

for thread in threads:
  thread.join()

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")


#Syncronization issues using thread:
#Balance added is 100 times:


import threading

balance=200

def deposit(amount,times):
  global balance
  for _ in range(times):
    balance+=amount

def withdraw(amount,times):
  global balance
  for _ in range(times):
    balance-=amount

deposit_thread=threading.Thread(target=deposit,args=[1,100])
withdraw_thread=threading.Thread(target=withdraw,args=[1,100])

deposit_thread.start()
withdraw_thread.start()

deposit_thread.join()
withdraw_thread.join()

print("After operation,balance is:",balance)

#Balance added is 10000 times:

import threading

balance=20000

def deposit(amount,times):
  global balance
  for _ in range(times):
    balance+=amount

def withdraw(amount,times):
  global balance
  for _ in range(times):
    balance-=amount

deposit_thread=threading.Thread(target=deposit,args=[1,10000])
withdraw_thread=threading.Thread(target=withdraw,args=[1,10000])

deposit_thread.start()
withdraw_thread.start()

deposit_thread.join()
withdraw_thread.join()

print("After operation,balance is:",balance)

#Balance added is 100000000 times:

import threading

balance=200000

def deposit(amount,times):
  global balance
  for _ in range(times):
    balance+=amount

def withdraw(amount,times):
  global balance
  for _ in range(times):
    balance-=amount

deposit_thread=threading.Thread(target=deposit,args=[1,1000000])
withdraw_thread=threading.Thread(target=withdraw,args=[1,1000000])

deposit_thread.start()
withdraw_thread.start()

deposit_thread.join()
withdraw_thread.join()

print("After operation,balance is:",balance)

#Usually balance jodi 100000 r upore deposit and withdraw kora hoi tobe multi-threading r un-syncronyzation r jonne total balance thik moto calculate korte pare na.But amr PC te parse.
#To overcome this problem:But ai process a code execution time aktu besi lagbe.

from time import time
import threading

start_time= time()
balance = 200000

lock = threading.Lock()

def deposit(amount, times, lock):
    global balance
    for _ in range(times):
        lock.acquire()
        balance += amount
        lock.release()

def withdraw(amount, times, lock):
    global balance
    for _ in range(times):
        lock.acquire()
        balance -= amount
        lock.release()


deposit_thread = threading.Thread(target=deposit, args=[1, 1000000, lock])
withdraw_thread = threading.Thread(target=withdraw, args=[1, 1000000, lock])

deposit_thread.start()
withdraw_thread.start()

deposit_thread.join()
withdraw_thread.join()

end_time= time()

print("After operation,balance is:", balance)
print("Time taken:",end_time-start_time,"seconds")

#Same code Lock() use na korle time onk kom lagbe.
from time import time
import threading

start_time= time()
balance = 200000


def deposit(amount, times):
    global balance
    for _ in range(times):
  
        balance += amount
      

def withdraw(amount, times):
    global balance
    for _ in range(times):
     
        balance -= amount
     

deposit_thread = threading.Thread(target=deposit, args=[1, 1000000])
withdraw_thread = threading.Thread(target=withdraw, args=[1, 1000000])

deposit_thread.start()
withdraw_thread.start()

deposit_thread.join()
withdraw_thread.join()

end_time= time()

print("After operation,balance is:", balance)
print("Time taken:",end_time-start_time,"seconds")


#ThreadPoolExecutors:

from time import sleep, time
from concurrent.futures import ThreadPoolExecutor, as_completed

start_time=time()

def something(id): 

  print(f"Sleep for 1 seconds,ID: {id}")
  sleep(1)
  return f"Wake up,ID: {id}"

with ThreadPoolExecutor() as executor:
   
  task=executor.submit(something,0)
  print(task.result())

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")


#For multiple task:
from time import sleep, time
from concurrent.futures import ThreadPoolExecutor, as_completed

start_time=time()

def something(id): 

  print(f"Sleep for 1 seconds,ID: {id}")
  sleep(1)
  return f"Wake up,ID: {id}"

with ThreadPoolExecutor() as executor:
  
  tasks=[executor.submit(something,i) for i in range(10)]

  for _ in as_completed(tasks):
    print(_.result())

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")

print(" ")
print("Using Map method:")
print(" ")

#Thread Pool Executor using MAP method:
from time import sleep, time
from concurrent.futures import ThreadPoolExecutor, as_completed

start_time=time()

def something(id): 

  print(f"Sleep for 1 seconds,ID: {id}")
  sleep(1)
  return f"Wake up,ID: {id}"

ids=[0,1,2,3,4,5,6,7,8,9]

with ThreadPoolExecutor() as executor:
  results=executor.map(something,ids)

  for result in results:
    print(result)

 
end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")


#Maximum Number of worker for a particular task:

from time import sleep, time
from concurrent.futures import ThreadPoolExecutor, as_completed

start_time=time()

def something(id): 

  print(f"Sleep for 1 seconds,ID: {id}")
  sleep(1)
  return f"Wake up,ID: {id}"

with ThreadPoolExecutor(max_workers=10) as executor:

  tasks=[executor.submit(something,i) for i in range(10)]

  for _ in as_completed(tasks):
    print(_.result())

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")


from time import sleep, time
from concurrent.futures import ThreadPoolExecutor, as_completed

start_time=time()

def something(id): 

  print(f"Sleep for 1 seconds,ID: {id}")
  sleep(1)
  return f"Wake up,ID: {id}"

with ThreadPoolExecutor(max_workers=5) as executor:

  tasks=[executor.submit(something,i) for i in range(10)]

  for _ in as_completed(tasks):
    print(_.result())

end_time=time()

print(f"Main thread ended in {end_time-start_time} seconds")












